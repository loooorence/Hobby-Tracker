import SideBar from './components/SideBar';

export function Index() {
  /*
   * Replace the elements below with your own.
   *
   * Note: The corresponding styles are in the ./index.css file.
   */
  return (
    <div>
      <SideBar />
    </div>
  );
}

export default Index;
